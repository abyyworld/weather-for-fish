// Terra Arcana - Core Application Logic
// Handles Map, Drawing Circle, Reverse Geocoding & Esoteric News Aggregation

let map;
let activeCircle = null;
let activeCenterMarker = null;
let articleMarkers = [];
let allArticles = [];
let currentFilter = 'all';

// State for drawing mode
let isDrawMode = false;
let drawStep = 0; // 0 = inactive, 1 = center selected / moving radius
let drawCenter = null;
let tempCircle = null;

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  initMap();
  initHotspotSelector();
  initEventListeners();
  lucide.createIcons();
});

// Initialize Leaflet Map
function initMap() {
  // Center near Europe / Atlantic for broad overview initially
  map = L.map('map', {
    zoomControl: false,
    minZoom: 2,
    maxZoom: 18
  }).setView([51.1789, -1.8262], 6); // Default view over UK/Wiltshire

  // Re-add zoom control to bottom right
  L.control.zoom({ position: 'bottomright' }).addTo(map);

  // 100% Free Tile Layers (NO API KEYS REQUIRED)
  const esriDark = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}', {
    attribution: 'Tiles &copy; Esri &mdash; Esri, DeLorme, NAVTEQ',
    maxZoom: 16
  });

  const esriDarkLabels = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}', {
    attribution: '',
    maxZoom: 16
  });

  const darkTacticalGroup = L.layerGroup([esriDark, esriDarkLabels]);

  const openStreetMap = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    maxZoom: 19
  });

  const satelliteImagery = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
    maxZoom: 18
  });

  // Add the tactical dark group as default
  darkTacticalGroup.addTo(map);

  // Layer control switcher (top left, below header)
  const baseMaps = {
    "🌙 Tactical Dark": darkTacticalGroup,
    "🛰️ Satellite Imagery": satelliteImagery,
    "🗺️ OpenStreetMap": openStreetMap
  };
  L.control.layers(baseMaps, null, { position: 'topleft' }).addTo(map);

  // Invalidate map size so it fits container perfectly on startup
  setTimeout(() => { map.invalidateSize(); }, 150);
  setTimeout(() => { map.invalidateSize(); }, 600);
  window.addEventListener('resize', () => { if (map) map.invalidateSize(); });

  // Map interaction events for circle drawing
  map.on('click', handleMapClick);
  map.on('mousemove', handleMapMouseMove);
}

// Populate the preset hotspots dropdown
function initHotspotSelector() {
  const select = document.getElementById('hotspotSelector');
  if (!select || !window.ESOTERIC_HOTSPOTS) return;

  ESOTERIC_HOTSPOTS.forEach(spot => {
    const opt = document.createElement('option');
    opt.value = spot.id;
    opt.textContent = `${spot.name} (${spot.badge})`;
    select.appendChild(opt);
  });

  select.addEventListener('change', (e) => {
    const spot = ESOTERIC_HOTSPOTS.find(s => s.id === e.target.value);
    if (spot) {
      jumpToLocation(spot.lat, spot.lng, spot.radius, spot.name);
    }
  });
}

// Initialize UI Event Listeners
function initEventListeners() {
  // Draw Mode Button
  const btnDraw = document.getElementById('btnDrawMode');
  btnDraw.addEventListener('click', toggleDrawMode);

  // Locate Me Button
  const btnLocate = document.getElementById('btnLocateMe');
  btnLocate.addEventListener('click', locateUser);

  // Radius Slider
  const slider = document.getElementById('radiusSlider');
  const radiusLabel = document.getElementById('radiusLabel');
  slider.addEventListener('input', (e) => {
    const km = parseFloat(e.target.value);
    radiusLabel.textContent = `${km.toFixed(1)} km`;
    if (activeCircle) {
      activeCircle.setRadius(km * 1000);
    }
  });

  // Rescan / Sweep Button
  document.getElementById('btnRescan').addEventListener('click', () => {
    if (activeCircle) {
      const center = activeCircle.getLatLng();
      const radius = activeCircle.getRadius();
      scanArea(center.lat, center.lng, radius);
    }
  });

  // Filter Tabs
  document.querySelectorAll('.filter-tab').forEach(tab => {
    tab.addEventListener('click', (e) => {
      document.querySelectorAll('.filter-tab').forEach(t => {
        t.classList.remove('active', 'bg-cyan-950', 'text-cyan-300', 'border-cyan-500/40');
        t.classList.add('bg-arcana-850', 'text-slate-400', 'border-slate-800');
      });
      const target = e.currentTarget;
      target.classList.add('active', 'bg-cyan-950', 'text-cyan-300', 'border-cyan-500/40');
      target.classList.remove('bg-arcana-850', 'text-slate-400', 'border-slate-800');

      currentFilter = target.getAttribute('data-filter');
      renderArticles();
    });
  });

  // Mobile Sidebar Toggle
  const sidebar = document.getElementById('sidebar');
  document.getElementById('btnToggleSidebar').addEventListener('click', () => {
    sidebar.classList.toggle('translate-x-full');
  });
  document.getElementById('btnCloseSidebar').addEventListener('click', () => {
    sidebar.classList.add('translate-x-full');
  });

  // Modal Close
  document.getElementById('btnCloseModal').addEventListener('click', closeModal);
  document.getElementById('detailModal').addEventListener('click', (e) => {
    if (e.target.id === 'detailModal') closeModal();
  });

  // ESC key cancels drawing or closes modal
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (isDrawMode) cancelDrawMode();
      closeModal();
    }
  });
}

// Toggle Drawing Mode
function toggleDrawMode() {
  if (isDrawMode) {
    cancelDrawMode();
  } else {
    startDrawMode();
  }
}

function startDrawMode() {
  isDrawMode = true;
  drawStep = 0;
  drawCenter = null;

  const btn = document.getElementById('btnDrawMode');
  btn.classList.add('ring-2', 'ring-cyan-400', 'from-rose-600', 'to-red-600');
  btn.innerHTML = `<i data-lucide="x" class="w-4 h-4"></i><span>Cancel Draw</span>`;
  lucide.createIcons();

  const mapEl = document.getElementById('map');
  mapEl.classList.add('map-crosshair');

  const instruction = document.getElementById('drawingInstruction');
  const instructionText = document.getElementById('instructionText');
  instruction.classList.remove('hidden');
  instructionText.textContent = "Step 1: Click anywhere on the map to set the radar center";
}

function cancelDrawMode() {
  isDrawMode = false;
  drawStep = 0;
  drawCenter = null;

  if (tempCircle) {
    map.removeLayer(tempCircle);
    tempCircle = null;
  }

  const btn = document.getElementById('btnDrawMode');
  btn.classList.remove('ring-2', 'ring-cyan-400', 'from-rose-600', 'to-red-600');
  btn.innerHTML = `<i data-lucide="circle-dot" class="w-4 h-4"></i><span>Draw Circle</span>`;
  lucide.createIcons();

  const mapEl = document.getElementById('map');
  mapEl.classList.remove('map-crosshair');

  document.getElementById('drawingInstruction').classList.add('hidden');
}

// Map Click Handler for Drawing Circle
function handleMapClick(e) {
  if (!isDrawMode) return;

  if (drawStep === 0) {
    // Step 1: Center chosen
    drawCenter = e.latlng;
    drawStep = 1;

    // Create live preview circle with initial radius of 2km
    tempCircle = L.circle(drawCenter, {
      radius: 2000,
      color: '#22d3ee',
      fillColor: '#0891b2',
      fillOpacity: 0.15,
      weight: 2,
      dashArray: '6, 8',
      className: 'radar-circle-animated'
    }).addTo(map);

    const instructionText = document.getElementById('instructionText');
    instructionText.textContent = "Step 2: Move cursor to expand radius, then click again to sweep area";

  } else if (drawStep === 1) {
    // Step 2: Radius locked
    const distanceMeters = drawCenter.distanceTo(e.latlng);
    const finalRadius = Math.max(distanceMeters, 1000); // At least 1 km

    if (tempCircle) {
      map.removeLayer(tempCircle);
      tempCircle = null;
    }

    commitCircle(drawCenter.lat, drawCenter.lng, finalRadius);
    cancelDrawMode();
  }
}

// Mouse Move Handler (live-updates circle radius during draw mode)
function handleMapMouseMove(e) {
  if (!isDrawMode || drawStep !== 1 || !drawCenter || !tempCircle) return;

  const distanceMeters = drawCenter.distanceTo(e.latlng);
  const radiusKm = (distanceMeters / 1000).toFixed(1);
  tempCircle.setRadius(distanceMeters);

  const instructionText = document.getElementById('instructionText');
  instructionText.textContent = `Radius: ${radiusKm} km — Click now to lock and sweep`;
}

// Commit and render the active circle
function commitCircle(lat, lng, radiusMeters) {
  // Remove existing circle and center marker
  if (activeCircle) map.removeLayer(activeCircle);
  if (activeCenterMarker) map.removeLayer(activeCenterMarker);

  // Create Center Marker with radar pulse
  const centerIcon = L.divIcon({
    className: 'custom-radar-pin',
    html: `
      <div class="relative flex items-center justify-center">
        <span class="pin-pulse border-cyan-400"></span>
        <div class="pin-core bg-cyan-400 shadow-[0_0_12px_#22d3ee]"></div>
      </div>
    `,
    iconSize: [28, 28],
    iconAnchor: [14, 14]
  });

  activeCenterMarker = L.marker([lat, lng], { icon: centerIcon }).addTo(map);

  // Create Active Circle
  activeCircle = L.circle([lat, lng], {
    radius: radiusMeters,
    color: '#22d3ee',
    fillColor: '#0891b2',
    fillOpacity: 0.12,
    weight: 2,
    className: 'radar-circle-animated'
  }).addTo(map);

  // Update floating radius slider
  const radiusKm = radiusMeters / 1000;
  const slider = document.getElementById('radiusSlider');
  slider.value = Math.min(Math.max(radiusKm, 1), 30);
  document.getElementById('radiusLabel').textContent = `${radiusKm.toFixed(1)} km`;
  document.getElementById('radiusControlBar').classList.remove('hidden');

  // Trigger data scan
  scanArea(lat, lng, radiusMeters);
}

// Jump to preset location
function jumpToLocation(lat, lng, radiusMeters, name) {
  map.flyTo([lat, lng], 12, { duration: 1.5 });
  setTimeout(() => {
    commitCircle(lat, lng, radiusMeters);
  }, 800);
}

// HTML5 Geolocation
function locateUser() {
  if (!navigator.geolocation) {
    alert("Geolocation is not supported by your browser.");
    return;
  }

  const btn = document.getElementById('btnLocateMe');
  btn.innerHTML = `<i data-lucide="loader-2" class="w-4 h-4 animate-spin text-cyan-400"></i><span class="hidden md:inline">Locating...</span>`;
  lucide.createIcons();

  navigator.geolocation.getCurrentPosition(
    (pos) => {
      const lat = pos.coords.latitude;
      const lng = pos.coords.longitude;
      map.flyTo([lat, lng], 13, { duration: 1.5 });
      commitCircle(lat, lng, 6000);
      btn.innerHTML = `<i data-lucide="crosshair" class="w-4 h-4"></i><span class="hidden md:inline">Locate Me</span>`;
      lucide.createIcons();
    },
    (err) => {
      alert("Unable to retrieve location: " + err.message);
      btn.innerHTML = `<i data-lucide="crosshair" class="w-4 h-4"></i><span class="hidden md:inline">Locate Me</span>`;
      lucide.createIcons();
    },
    { timeout: 8000 }
  );
}

// Core Data Engine: Reverse Geocoding + Wikipedia GeoSearch + Enrichment
async function scanArea(lat, lng, radiusMeters) {
  const startTime = performance.now();
  setLoadingState(true);

  // Update Coords in sidebar
  const radiusKm = (radiusMeters / 1000).toFixed(1);
  document.getElementById('areaCoords').textContent = `Lat: ${lat.toFixed(4)} | Lon: ${lng.toFixed(4)} | Sweep: ${radiusKm} km`;
  document.getElementById('scanStatus').textContent = "SCANNING SECTOR...";

  // 1. Reverse Geocode with OpenStreetMap Nominatim
  reverseGeocode(lat, lng);

  // 2. Fetch Geo-articles from Wikipedia GeoSearch API
  try {
    // GeoSearch API caps radius at 10,000m (10km) per call
    const queryRadius = Math.min(Math.round(radiusMeters), 10000);
    const geoUrl = `https://en.wikipedia.org/w/api.php?action=query&list=geosearch&gscoord=${lat}|${lng}&gsradius=${queryRadius}&gslimit=35&format=json&origin=*`;

    const geoRes = await fetch(geoUrl);
    const geoData = await geoRes.json();
    const geoItems = geoData?.query?.geosearch || [];

    if (geoItems.length === 0) {
      handleEmptyResults(lat, lng, radiusKm);
      setLoadingState(false);
      return;
    }

    // 3. Batch fetch extracts, thumbnails, and URLs for all returned pageids
    const pageIds = geoItems.map(item => item.pageid).slice(0, 30);
    const detailsUrl = `https://en.wikipedia.org/w/api.php?action=query&prop=extracts|pageimages|info&exintro=true&explaintext=true&exsentences=3&piprop=thumbnail&pithumbsize=500&inprop=url&pageids=${pageIds.join('|')}&format=json&origin=*`;

    const detailsRes = await fetch(detailsUrl);
    const detailsData = await detailsRes.json();
    const pages = detailsData?.query?.pages || {};

    // Combine & enrich articles
    allArticles = geoItems.map(geo => {
      const detail = pages[geo.pageid] || {};
      const title = geo.title || detail.title || "Unknown Record";
      const extract = detail.extract || "No archival excerpt available for this coordinate.";
      const thumbnail = detail.thumbnail ? detail.thumbnail.source : null;
      const url = detail.fullurl || `https://en.wikipedia.org/?curid=${geo.pageid}`;
      const distKm = (geo.dist / 1000).toFixed(2);

      const meta = categorizeArticle(title, extract);
      const fieldNote = generateEsotericFieldNote(title, meta.category, distKm);

      return {
        id: geo.pageid,
        title,
        lat: geo.lat,
        lng: geo.lon,
        distanceMeters: geo.dist,
        distanceKm: distKm,
        extract,
        thumbnail,
        url,
        category: meta.category,
        icon: meta.icon,
        colorBadge: meta.color,
        fieldNote
      };
    });

    // Sort by distance (closest first)
    allArticles.sort((a, b) => a.distanceMeters - b.distanceMeters);

    const elapsed = Math.round(performance.now() - startTime);
    document.getElementById('queryTiming').textContent = `${allArticles.length} dispatches in ${elapsed}ms`;
    document.getElementById('scanStatus').textContent = "RADAR ACTIVE";

    // Update Counters
    updateCategoryCounters();

    // Render Markers on Map & Cards in Feed
    renderMapMarkers();
    renderArticles();

  } catch (err) {
    console.error("Scan error:", err);
    document.getElementById('scanStatus').textContent = "SCAN OFFLINE";
    document.getElementById('articlesList').innerHTML = `
      <div class="p-4 rounded-xl bg-rose-950/40 border border-rose-500/40 text-xs text-rose-300">
        <p class="font-bold mb-1">Geospatial Relay Error</p>
        <p>${err.message}. Check network connection and retry.</p>
      </div>
    `;
  } finally {
    setLoadingState(false);
  }
}

// Reverse Geocode helper using OSM Nominatim
async function reverseGeocode(lat, lng) {
  try {
    const res = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&zoom=10`);
    const data = await res.json();

    if (data && data.address) {
      const addr = data.address;
      const place = addr.city || addr.town || addr.village || addr.municipality || addr.county || addr.state || "Uncharted Sector";
      const region = addr.state || addr.country || "";
      document.getElementById('areaTitle').textContent = region ? `${place}, ${region}` : place;
    } else {
      document.getElementById('areaTitle').textContent = `Coordinates [${lat.toFixed(2)}, ${lng.toFixed(2)}]`;
    }
  } catch (e) {
    document.getElementById('areaTitle').textContent = `Grid Sector [${lat.toFixed(2)}, ${lng.toFixed(2)}]`;
  }
}

// Render Pins on the Map
function renderMapMarkers() {
  // Clear previous markers
  articleMarkers.forEach(m => map.removeLayer(m));
  articleMarkers = [];

  const filtered = filterArticles(allArticles);

  filtered.forEach(art => {
    // Custom glowing icon per category
    let pinColor = '#22d3ee';
    if (art.category.includes('Folklore')) pinColor = '#c084fc';
    if (art.category.includes('Monoliths')) pinColor = '#fbbf24';
    if (art.category.includes('Mysteries')) pinColor = '#fb7185';
    if (art.category.includes('Aerospace')) pinColor = '#38bdf8';

    const icon = L.divIcon({
      className: 'custom-radar-pin',
      html: `
        <div class="relative flex items-center justify-center cursor-pointer group">
          <div class="pin-core" style="background-color: ${pinColor}; border-color: #fff;"></div>
        </div>
      `,
      iconSize: [16, 16],
      iconAnchor: [8, 8]
    });

    const marker = L.marker([art.lat, art.lng], { icon }).addTo(map);

    // Popup with thumbnail & snippet
    const popupHtml = `
      <div class="w-56 p-1 text-slate-100 font-sans">
        ${art.thumbnail ? `<img src="${art.thumbnail}" class="w-full h-24 object-cover rounded mb-2 border border-slate-700">` : ''}
        <span class="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded ${art.colorBadge}">${art.category}</span>
        <h4 class="font-bold text-xs mt-1 text-white">${escapeHtml(art.title)}</h4>
        <p class="text-[11px] text-cyan-400 font-mono mt-0.5">${art.distanceKm} km from center</p>
        <p class="text-[11px] text-slate-300 mt-1 line-clamp-2">${escapeHtml(art.extract)}</p>
        <button onclick="openArticleModal('${art.id}')" class="mt-2 w-full bg-cyan-950 hover:bg-cyan-900 text-cyan-300 text-[10px] font-mono py-1 rounded border border-cyan-500/40">
          Open Field Dispatch
        </button>
      </div>
    `;

    marker.bindPopup(popupHtml);
    articleMarkers.push(marker);
  });
}

// Render Cards in Sidebar
function renderArticles() {
  const container = document.getElementById('articlesList');
  const filtered = filterArticles(allArticles);

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="text-center py-12 text-slate-400">
        <i data-lucide="filter-x" class="w-8 h-8 mx-auto text-slate-500 mb-2"></i>
        <p class="text-xs font-mono">No dispatches match the "${currentFilter}" filter.</p>
      </div>
    `;
    lucide.createIcons();
    return;
  }

  let html = '';
  filtered.forEach(art => {
    html += `
      <article onclick="openArticleModal('${art.id}')" class="group relative bg-arcana-900/70 hover:bg-arcana-850 border border-slate-800 hover:border-cyan-500/50 rounded-xl p-3.5 transition-all duration-200 cursor-pointer shadow-lg hover:shadow-[0_4px_20px_rgba(34,211,238,0.12)]">
        <div class="flex gap-3">
          ${art.thumbnail ? `
            <div class="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0 border border-slate-800 bg-black">
              <img src="${art.thumbnail}" alt="${escapeHtml(art.title)}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
            </div>
          ` : `
            <div class="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0 border border-slate-800 bg-cyan-950/30 flex items-center justify-center text-cyan-400/50">
              <i data-lucide="${art.icon || 'compass'}" class="w-7 h-7"></i>
            </div>
          `}
          
          <div class="flex-1 min-w-0">
            <div class="flex items-center justify-between gap-1 mb-1">
              <span class="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded border ${art.colorBadge} truncate">
                ${art.category}
              </span>
              <span class="text-[10px] font-mono text-cyan-400/90 whitespace-nowrap flex items-center space-x-1">
                <i data-lucide="navigation" class="w-2.5 h-2.5"></i>
                <span>${art.distanceKm} km</span>
              </span>
            </div>

            <h3 class="font-bold text-xs text-white group-hover:text-cyan-300 transition line-clamp-1">
              ${escapeHtml(art.title)}
            </h3>

            <p class="text-[11px] text-slate-400 line-clamp-2 mt-1 leading-snug">
              ${escapeHtml(art.extract)}
            </p>
          </div>
        </div>

        <!-- Subtle Field Note Pill -->
        <div class="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500 font-mono">
          <span class="truncate italic text-slate-400 max-w-[280px]">“${escapeHtml(art.fieldNote)}”</span>
          <span class="text-cyan-400 group-hover:translate-x-0.5 transition flex items-center space-x-0.5">
            <span>Read</span>
            <i data-lucide="chevron-right" class="w-3 h-3"></i>
          </span>
        </div>
      </article>
    `;
  });

  container.innerHTML = html;
  lucide.createIcons();
}

// Filter helper
function filterArticles(articles) {
  if (currentFilter === 'all') return articles;
  return articles.filter(a => a.category.toLowerCase().includes(currentFilter.toLowerCase()));
}

// Update counters on filter tabs
function updateCategoryCounters() {
  document.getElementById('countAll').textContent = allArticles.length;
}

// Handle empty results gracefully (e.g. middle of ocean or uninhabited desert)
function handleEmptyResults(lat, lng, radiusKm) {
  document.getElementById('scanStatus').textContent = "ZERO TERRESTRIAL ARCHIVES";
  document.getElementById('articlesList').innerHTML = `
    <div class="text-center py-10 px-4">
      <div class="w-14 h-14 rounded-full bg-arcana-850 border border-slate-700 flex items-center justify-center mx-auto text-slate-400 mb-3">
        <i data-lucide="waves" class="w-7 h-7 text-cyan-400"></i>
      </div>
      <h3 class="text-sm font-bold text-slate-200 font-mono">UNRECORDED / REMOTE SECTOR</h3>
      <p class="text-xs text-slate-400 max-w-xs mx-auto mt-1 leading-relaxed">
        No geo-indexed articles within ${radiusKm} km. This typically indicates open water, dense wilderness, or unmonitored desert expanse.
      </p>

      <div class="mt-5 space-y-2">
        <button onclick="expandRadiusTo(25)" class="w-full bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/40 text-xs font-mono py-2 rounded-lg transition">
          📡 Expand Radar Sweep to 25 km
        </button>
        <button onclick="jumpToLocation(57.3229, -4.4244, 8000, 'Loch Ness')" class="w-full bg-arcana-850 hover:bg-arcana-800 text-slate-300 border border-slate-700 text-xs font-mono py-2 rounded-lg transition">
          🐉 Or Jump to Loch Ness Cryptid Hotspot
        </button>
      </div>
    </div>
  `;
  lucide.createIcons();
}

function expandRadiusTo(newRadiusKm) {
  if (!activeCircle) return;
  const center = activeCircle.getLatLng();
  commitCircle(center.lat, center.lng, newRadiusKm * 1000);
}

// Detail Modal
window.openArticleModal = function(id) {
  const art = allArticles.find(a => a.id == id);
  if (!art) return;

  document.getElementById('modalTitle').textContent = art.title;
  document.getElementById('modalCategory').textContent = art.category;
  document.getElementById('modalCategory').className = `text-[10px] font-mono uppercase px-2 py-0.5 rounded border ${art.colorBadge}`;
  document.getElementById('modalDistance').textContent = `Coordinate Displacement: ${art.distanceKm} km from perimeter center`;
  document.getElementById('modalExtract').textContent = art.extract;
  document.getElementById('modalFieldNote').textContent = art.fieldNote;
  document.getElementById('modalExternalLink').href = art.url;

  const imgContainer = document.getElementById('modalImageContainer');
  const imgEl = document.getElementById('modalImage');
  if (art.thumbnail) {
    imgEl.src = art.thumbnail;
    imgContainer.classList.remove('hidden');
  } else {
    imgContainer.classList.add('hidden');
  }

  // Button to focus pin on map
  const btnFocus = document.getElementById('btnFocusArticleOnMap');
  btnFocus.onclick = () => {
    closeModal();
    map.flyTo([art.lat, art.lng], 15, { duration: 1.2 });
    // Find corresponding marker and trigger popup
    const marker = articleMarkers.find(m => {
      const pos = m.getLatLng();
      return Math.abs(pos.lat - art.lat) < 0.0001 && Math.abs(pos.lng - art.lng) < 0.0001;
    });
    if (marker) {
      setTimeout(() => marker.openPopup(), 1300);
    }
  };

  document.getElementById('detailModal').classList.remove('hidden');
  lucide.createIcons();
};

function closeModal() {
  document.getElementById('detailModal').classList.add('hidden');
}

// UI State
function setLoadingState(loading) {
  const indicator = document.getElementById('loadingIndicator');
  const initial = document.getElementById('emptyInitial');
  if (loading) {
    indicator.classList.remove('hidden');
    if (initial) initial.classList.add('hidden');
  } else {
    indicator.classList.add('hidden');
  }
}

// Utility: XSS prevention
function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
