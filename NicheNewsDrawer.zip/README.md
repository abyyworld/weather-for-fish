# Terra Arcana 📡
### Esoteric & Niche Geo-News & Lore Radar

> **Hackathon Theme:** *Esoteric and Niche*  
> **Built for:** Builders Club Hackathon 2026

---

## ⚡ What is Terra Arcana?
Mainstream news aggregators push homogenous viral headlines from capital cities. **Terra Arcana** is a tactical geospatial intelligence interface that lets users draw a circle anywhere on Earth to unearth:
- **Hyper-local micro-news** and community press.
- **Forgotten folklore, cryptids, and occult phenomena**.
- **Anomalous aerospace encounters and classified lore**.
- **Neolithic monoliths, sacred geometries, and ancient ruins**.
- **Unsolved local mysteries and historical divergence points**.

---

## 🚀 Quick Start
- Simply double-click **`run.bat`** (or open **`index.html`** in Chrome / Brave / Edge).
- Alternatively, run `./serve.ps1` in PowerShell to host locally on `http://localhost:8000`.

---

## 🧭 How to Demo to Judges (2-Minute Pitch)

1. **The Hook (30s):**
   > *"When you open Google News, you see the same 10 global headlines. But every single square kilometer of our planet has unique, bizarre micro-histories, local lore, and niche news that never surfaces. We built Terra Arcana to invert the algorithm."*

2. **The Interactive Feature (45s):**
   - Click the **"Draw Circle"** button in the top bar.
   - Click on the map to set a center (e.g., in the Scottish Highlands or Nevada desert), then move the mouse to expand the radar radius.
   - Release: the app live-intercepts geo-indexed archives, calculates exact kilometer offsets, classifies the findings, and pins them with glowing radar markers.

3. **Showcase the Esoteric Angle (30s):**
   - Use the **"Jump to Esoteric Hotspot"** dropdown to demonstrate:
     - 🛸 **Area 51 & Groom Lake:** Secret aerospace records and UFO incident lore.
     - 🐉 **Loch Ness & Urquhart:** Cryptid sonar contacts and Highland Pictish history.
     - 🏰 **Rennes-le-Château:** Coded parchments and Templar Grail lore.
     - 🌲 **Pine Barrens:** The 1735 Leeds Devil and abandoned iron ghost towns.

4. **Category Filtering & Deep Dive (15s):**
   - Click filter chips: *🛸 Anomalies*, *🐉 Cryptids*, *🏛️ Megaliths*, *⚠️ Mysteries*.
   - Click any card to open the **Archival Field Dispatch** and view its photo, excerpt, and synthetic esoteric field note.

---

## 🛠️ Architecture & Zero-Friction Stack
- **Zero build dependencies**: Runs immediately in any browser without npm install or backend setup.
- **Tactical Cartography**: Leaflet.js with CartoDB Dark Matter tiles.
- **Geocoding Engine**: OpenStreetMap Nominatim reverse geocoder (free, no API key).
- **Intelligence Archive**: Wikipedia GeoSearch & PageImages API (CORS enabled, real-time radius querying).
- **Classification Engine**: Dynamic regex heuristics categorizing dispatches into esoteric taxonomies.
