// Curated Esoteric Hotspots and Fallback Intelligence Database
// Used for instant demo buttons and intelligent enrichment

const ESOTERIC_HOTSPOTS = [
  {
    id: "area51",
    name: "Area 51 & Groom Lake",
    region: "Nevada, USA",
    lat: 37.2431,
    lng: -115.7930,
    radius: 12000,
    badge: "Classified Aerospace",
    description: "Sub-surface hangar anomalies, classified radar testing, and 70 years of UFO lore in the Papoose Range."
  },
  {
    id: "lochness",
    name: "Loch Ness & Urquhart",
    region: "Highlands, Scotland",
    lat: 57.3229,
    lng: -4.4244,
    radius: 8000,
    badge: "Cryptozoology",
    description: "Deep freshwater trench harboring centuries of cryptid folklore, sonar contact anomalies, and Pictish carvings."
  },
  {
    id: "pointpleasant",
    name: "Point Pleasant TNT Area",
    region: "West Virginia, USA",
    lat: 38.8437,
    lng: -82.1413,
    radius: 6000,
    badge: "Urban Legend & Folklore",
    description: "Epicenter of the 1966 Mothman sightings, abandoned WWII munitions bunkers, and Silver Bridge phenomena."
  },
  {
    id: "rennes",
    name: "Rennes-le-Château",
    region: "Occitanie, France",
    lat: 42.9281,
    lng: 2.2628,
    radius: 5000,
    badge: "Occult & Templar Lore",
    description: "Hilltop village linked to Abbé Saunière's sudden fortune, coded parchments, and Grail/Visigoth legends."
  },
  {
    id: "sedona",
    name: "Sedona Vortices",
    region: "Arizona, USA",
    lat: 34.8697,
    lng: -111.7610,
    radius: 7000,
    badge: "Geomagnetic Anomalies",
    description: "Red rock canyon complex alleged to host swirling subtle energy vortexes and geomagnetic twists in juniper trees."
  },
  {
    id: "hoiabaciu",
    name: "Hoia-Baciu Forest",
    region: "Cluj-Napoca, Romania",
    lat: 46.7725,
    lng: 23.5186,
    radius: 4000,
    badge: "Paranormal & Botany",
    description: "Often termed the Bermuda Triangle of Transylvania; famous for curved vegetative growth and nocturnal lights."
  },
  {
    id: "pinebarrens",
    name: "Pine Barrens Ghost Towns",
    region: "New Jersey, USA",
    lat: 39.8153,
    lng: -74.5218,
    radius: 10000,
    badge: "Folkloric Cryptid",
    description: "1.1 million acres of pitch pine wilderness, abandoned iron furnace ruins, and domain of the Leeds Devil (1735)."
  },
  {
    id: "stonehenge",
    name: "Wiltshire Megaliths & Crop Circles",
    region: "Wiltshire, England",
    lat: 51.1789,
    lng: -1.8262,
    radius: 9000,
    badge: "Archaeoastronomy",
    description: "Neolithic henge monument aligned to solstices, dense cluster of barrows, and seasonal crop formation phenomena."
  }
];

// Heuristics to classify and tag articles into esoteric & niche categories
function categorizeArticle(title, extract) {
  const text = (title + " " + extract).toLowerCase();

  if (/ufo|alien|extraterrestrial|saucer|radar|aircraft|black project|conspiracy|classified|secret/.test(text)) {
    return { category: "Anomalies & Aerospace", icon: "orbit", color: "text-cyan-400 bg-cyan-950/60 border-cyan-800" };
  }
  if (/cryptid|monster|creature|folklore|legend|devil|beast|serpent|ghost|haunt|specter|phantom/.test(text)) {
    return { category: "Folklore & Cryptids", icon: "sparkles", color: "text-purple-400 bg-purple-950/60 border-purple-800" };
  }
  if (/ruin|ancient|castle|tomb|barrow|megalith|stone|neolithic|temple|monastery|priory|church|cathedral/.test(text)) {
    return { category: "Ancient Monoliths & Sacred Sites", icon: "landmark", color: "text-amber-400 bg-amber-950/60 border-amber-800" };
  }
  if (/murder|mystery|disappearance|unsolved|disaster|shipwreck|cave|mine|explosion|bunker|abandoned/.test(text)) {
    return { category: "Unsolved Mysteries & Oddities", icon: "alert-triangle", color: "text-rose-400 bg-rose-950/60 border-rose-800" };
  }
  if (/nature reserve|forest|volcano|crater|spring|fault|geology|meteorite|island|bog/.test(text)) {
    return { category: "Earth Curiosities & Terrain", icon: "compass", color: "text-emerald-400 bg-emerald-950/60 border-emerald-800" };
  }
  return { category: "Hyper-Local Dispatch", icon: "newspaper", color: "text-blue-400 bg-blue-950/60 border-blue-800" };
}

// Generate esoteric synthetic analysis / field note for an article
function generateEsotericFieldNote(title, category, distanceKm) {
  const notes = [
    `Geospatial reading confirms locus at ${distanceKm} km from perimeter center. Sub-surface and archival records flag this site for unusual historical divergence.`,
    `Archival footprint indicates non-standard regional significance. Often omitted from standard travel itineraries and macro-news aggregation.`,
    `Localized historical frequency detected. Micro-events recorded at this coordinate correlate with distinct regional folklore traditions.`,
    `Field surveillance note: High concentration of niche oral history and hyper-local records clustered around this waypoint.`
  ];
  return notes[Math.floor(Math.random() * notes.length)];
}
